import 'package:flutter/material.dart';

class Guest extends StatelessWidget {

Guest({this.username, this.userid});
final String username;
  final String userid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("GUESTSS $username"),),
      body: Column(
        children: <Widget>[
          Text('Hello $username', style: TextStyle(fontSize: 20.0),),

          RaisedButton(
            child: Text("Log Out"),
            onPressed: (){
              Navigator.pushReplacementNamed(context,'/MyHomePage');
            },
          ),
        ],
      ),
    );
  }
}